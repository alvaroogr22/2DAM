package application;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.DialogPane;
import javafx.scene.control.Label;

public class Controller {

    @FXML
    private DialogPane dialogPane;

    @FXML
    private Label label;

    @FXML
    private Button button;

    // Resto del código de la clase controladora
}