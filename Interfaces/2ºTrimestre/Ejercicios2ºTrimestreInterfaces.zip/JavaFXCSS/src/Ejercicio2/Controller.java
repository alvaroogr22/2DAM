package Ejercicio2;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;

public class Controller {

    @FXML
    private Pane pane;

    @FXML
    private Label labelName;

    @FXML
    private Label labelPassword;
    
    @FXML
    private TextField tfName;
    
    @FXML
    private TextField tfPassword;
    
    @FXML
    private Button button;

    // Resto del código de la clase controladora
}