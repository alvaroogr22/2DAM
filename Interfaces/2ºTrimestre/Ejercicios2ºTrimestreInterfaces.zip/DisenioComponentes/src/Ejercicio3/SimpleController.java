package Ejercicio3;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;

public class SimpleController {

	@FXML
	private void pulsame(ActionEvent event) {
		System.out.println("Has pulsado el botón!");
	}
}
