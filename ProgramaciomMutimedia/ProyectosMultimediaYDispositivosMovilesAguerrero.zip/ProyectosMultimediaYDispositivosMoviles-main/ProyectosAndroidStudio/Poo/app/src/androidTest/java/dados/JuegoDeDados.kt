package dados

fun main(parametro: Array<String>){
valk juego1=JuegoDeDados()
        juego1.jugar()
}