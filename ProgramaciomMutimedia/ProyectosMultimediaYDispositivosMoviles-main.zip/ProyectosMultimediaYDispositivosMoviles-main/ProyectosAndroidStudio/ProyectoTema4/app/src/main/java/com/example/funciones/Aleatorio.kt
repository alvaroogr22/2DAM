package com.example.funciones

import kotlin.random.Random

fun main(){
 var ale1=Random.nextInt(1,3)
    println("el  numero elegido es $ale1")

}