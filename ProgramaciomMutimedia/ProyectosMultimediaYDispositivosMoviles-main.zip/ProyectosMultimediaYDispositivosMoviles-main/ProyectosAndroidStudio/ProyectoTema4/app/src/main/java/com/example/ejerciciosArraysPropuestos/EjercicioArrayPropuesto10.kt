package com.example.arrays

fun main() {
  
}
