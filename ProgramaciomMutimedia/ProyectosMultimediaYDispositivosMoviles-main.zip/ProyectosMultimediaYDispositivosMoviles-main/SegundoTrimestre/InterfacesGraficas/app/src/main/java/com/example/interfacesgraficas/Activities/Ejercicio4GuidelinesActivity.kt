package com.example.interfacesgraficas.Activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.interfacesgraficas.R

class Ejercicio4GuidelinesActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ejercicio4_guidelines)
    }
}