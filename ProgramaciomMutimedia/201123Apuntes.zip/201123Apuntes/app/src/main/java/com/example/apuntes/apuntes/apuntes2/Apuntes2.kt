package com.example.apuntes.apuntes.apuntes2

fun main() {
    /*
    // suma de 2 en 2
    for (a in 0..10 step 2) {
        println(a)
    }

    // suma de 2 en 2
    for (b in 10 downTo 0 step 2) {
        println(b)
    }

    // tabla de multiplicar del 5 bucle for
    for (i in 10 downTo 0) {
        val resultado = 5 * i
        println("5 * $i = $resultado")
    }

    // tabla de multiplicar del 5 bucle while
    var i = 1
    while (i <= 10) {
        val resultado = 5 * i
        println("5 * $i = $resultado")
        i++
    }

    // tabla de multiplicar del 5 bucle do..while
    var o = 1
    do {
        val resultado2 = 5 * o
        println("5 * $o = $resultado2")
        o++
    } while (o <= 10)

    // ? es para gestionar los valores nulos, que se pueda escribir nulos en este caso
    // al ser un lenguaje interpretado no es necesario definir las variables
    println("Ingrese un número del 0 al 10 y te digo qué nota tienes")
    val numero: Int? = readLine()?.toInt()
    when (numero) {
        0, 1, 2, 3, 4 -> println("Suspenso")
        5 -> println("Suficiente")
        6 -> println("Bien")
        7, 8 -> println("Notable")
        9, 10 -> println("Sobresaliente")
        else -> println("Número no válido. Ingrese un número del 0 al 10")
    }

    println("Ingrese un número del 1 al 8 y te digo qué día es")
    val numero: Int? = readLine()?.toInt()
    when (numero) {
        1 -> println("Lunes")
        2 -> println("Martes")
        3 -> println("Miércoles")
        4 -> println("Jueves")
        5 -> println("Viernes")
        6 -> println("Sábado")
        7 -> println("Domingo")
        8 -> println("Día de Alberto")

        else -> println("Número no válido. Ingrese un número del 1 al 8")
    }

    println("Ingrese un número del 1 al 12 y te digo qué mes es")
    val numero: Int? = readLine()?.toInt()
    when (numero) {
        1 -> println("Enero")
        2 -> println("Febrero")
        3 -> println("Marzo")
        4 -> println("Abril")
        5 -> println("Mayo")
        6 -> println("Junio")
        7 -> println("Julio")
        8 -> println("Agosto")
        9 -> println("Septiembre")
        10 -> println("Octubre")
        11 -> println("Noviembre")
        12 -> println("Diciembre")

        else -> println("Número no válido. Ingrese un número del 1 al 12")
    }
    */
}