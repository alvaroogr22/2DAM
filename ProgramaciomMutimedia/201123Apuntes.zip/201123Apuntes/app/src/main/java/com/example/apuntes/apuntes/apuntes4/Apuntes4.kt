package com.example.apuntes.apuntes.apuntes4

import kotlin.random.Random

fun sumar1(a: Int, b: Int): Int {
    var resultado = a + b
    return resultado

}

fun resta1(a: Int, b: Int): Int {
    var resultado = a - b
    return resultado

}

fun multiplicacion1(a: Int, b: Int): Int {
    var resultado = a * b
    return resultado

}

fun division1(a: Int, b: Int): Int {
    var resultado = a / b
    return resultado

}


fun main() {

    var estaMenu: Boolean
    //suma
    /*println("Dime dos numeros y lo sumaré")
    var numero1 = readLine()?.toIntOrNull() ?: 0
    var numero2 = readLine()?.toIntOrNull() ?: 0

    var resultado = sumar(numero1, numero2)

    println("$resultado")
    // resta
    println("Dime dos numeros y lo restaré")
    var numero1 = readLine()?.toIntOrNull() ?: 0
    var numero2 = readLine()?.toIntOrNull() ?: 0

    var resultado = resta(numero1, numero2)

    println("$resultado")

    // multiplicación
    println("Dime dos numeros y lo multiplicare")
    var numero1 = readLine()?.toIntOrNull() ?: 0
    var numero2 = readLine()?.toIntOrNull() ?: 0

    var resultado = multiplicacion(numero1, numero2)

    println("$resultado")

    // division
    println("Dime dos numeros y lo multiplicare")
    var numero1 = readLine()?.toIntOrNull() ?: 0
    var numero2 = readLine()?.toIntOrNull() ?: 0

    var resultado = division(numero1, numero2)

    println("$resultado")

    var ale1=Random.nextInt(1,3)
    println("El número elegido es $ale1")*/

}