package com.example.proyectotema4

fun main(){
    println("Hola mundo")

}