package com.example.poo.herencia2

// Clase base: Producto
open class ProductoAlmacen(val nombre: String, val precio: Double) {
    fun mostrarDetalle() {
        println("Producto: $nombre, Precio: $precio")
    }
}

// Clase intermedia: Envio
open class Envio(nombre: String, precio: Double, val destino: String) : ProductoAlmacen(nombre, precio) {
    fun calcularCostoEnvio(): Double {
        // Supongamos que el costo de envío es un 10% del precio del producto
        return precio * 0.1
    }

    fun mostrarDetalleEnvio() {
        mostrarDetalle()
        println("Destino: $destino, Costo de Envío: ${calcularCostoEnvio()}")
    }
}

// Clase derivada: Factura
class Factura(nombre: String, precio: Double, destino: String, val numeroFactura: String) : Envio(nombre, precio, destino) {
    fun imprimirFactura() {
        mostrarDetalleEnvio()
        println("Número de Factura: $numeroFactura")
    }
}

fun main() {
    // Crear instancia de Factura y mostrar información
    val factura = Factura("Laptop", 1200.0, "Ciudad A", "F2023001")
    factura.imprimirFactura()
}
