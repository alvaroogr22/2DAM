package com.example.juegodelespia

import kotlin.random.Random

// Clase base Espia
open class Espia2 {
    var combinacionCorrecta: IntArray = IntArray(5)

    init {
        generarCombinacion()
    }

    private fun generarCombinacion() {
        for (i in 0 until 5) {
            combinacionCorrecta[i] = Random.nextInt(0, 10)
        }
    }

    open fun verificarCombinacion(intentoActual: IntArray): String {
        // Lógica para verificar y dar pistas
        if (intentoActual contentEquals combinacionCorrecta) {
            return "¡Combinación correcta!"
        }

        val pistas = StringBuilder()
        for (i in 0 until 5) {
            if (intentoActual[i] < combinacionCorrecta[i]) {
                pistas.append(">")
            } else if (intentoActual[i] > combinacionCorrecta[i]) {
                pistas.append("<")
            } else {
                pistas.append("=")
            }
        }
        return pistas.toString()
    }
}

// Clase derivada Mision
class Mision2 : Espia2() {
    var oportunidadesRestantes = 4

    fun jugar() {
        while (oportunidadesRestantes > 0) {
            val intento = solicitarIntento()
            val pistas = verificarCombinacion(intento)
            println("Pistas: $pistas")

            if (pistas == "¡Combinación correcta!") {
                println("¡Has tenido éxito en la misión!")
                return
            }

            oportunidadesRestantes--
        }

        println("¡Alarma activada! La SS está en camino. Misión fallida.")
    }

    private fun solicitarIntento(): IntArray {
        println("Ingresa tu intento (5 números del 0 al 9, separados por espacios):")
        val input = readLine()
        val numeros = input?.split(" ")?.map { it.toIntOrNull() }
        return numeros?.filterNotNull()?.toIntArray() ?: IntArray(5)
    }

    override fun verificarCombinacion(intentoActual: IntArray): String {
        return super.verificarCombinacion(intentoActual)
    }
}

fun main() {
    val mision = Mision2()
    mision.jugar()
}
