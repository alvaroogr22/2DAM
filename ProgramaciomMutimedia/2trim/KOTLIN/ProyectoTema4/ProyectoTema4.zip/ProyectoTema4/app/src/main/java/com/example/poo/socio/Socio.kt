package com.example.poo.socio

class Socio (val nombre: String, val antiguedad: Int) {
    fun imprimir() {
        println("$nombre tiene una antiguedad de $antiguedad")
    }
}
