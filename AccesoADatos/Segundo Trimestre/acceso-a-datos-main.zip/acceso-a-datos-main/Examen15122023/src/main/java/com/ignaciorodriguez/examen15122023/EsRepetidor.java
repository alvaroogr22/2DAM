package com.ignaciorodriguez.examen15122023;
//enum que indica si es repetidor
public enum EsRepetidor {
    sí,
    no
}
